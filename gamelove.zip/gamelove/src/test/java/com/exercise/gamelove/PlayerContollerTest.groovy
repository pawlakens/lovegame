package com.exercise.gamelove

import com.exercise.gamelove.controller.PlayerController
import com.exercise.gamelove.dto.LovedGamesDTO
import com.exercise.gamelove.dto.PlayerDTO
import com.exercise.gamelove.entity.Game
import com.exercise.gamelove.entity.Player
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.http.HttpStatus
import org.springframework.transaction.annotation.Transactional
import spock.lang.Specification

@Transactional
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class PlayerContollerTest extends Specification {

    @Autowired
    PlayerController playerController

    def "When add is called should return player instance and CREATED result code"() {
        given:
        def resultPlayer = new Player("user")
        def resultGame = new Game("sample")

        def playerDTO = new PlayerDTO("user", "sample")
        when:
        def result = playerController.add(playerDTO)
        then:
        result.getStatusCode() == HttpStatus.CREATED
        result.getBody() == resultPlayer
        result.getBody().getGames().contains(resultGame)
    }

    def "When remove is called and data is available should return OK return code and player instance"() {
        given:
        def playerDTO = new PlayerDTO("user", "sample")
        def resultPlayer = new Player("user")
        when:
        playerController.add(playerDTO)
        def result = playerController.remove(playerDTO)
        then:
        result.getStatusCode() == HttpStatus.OK
        result.getBody() == resultPlayer
        result.getBody().getGames().size() == 0
    }

    def "When remove is called and data is empty should return NOT FOUND code"() {
        given:
        def playerDTO = new PlayerDTO("user", "sample")
        when:
        def result = playerController.remove(playerDTO)
        then:
        result.getStatusCode() == HttpStatus.NOT_FOUND
    }

    def "When findByName is called should return OK code and valid game instances"() {
        when:
        playerController.add(dto)
        def result = playerController.findAllByPlayer(input)
        then:
        result.getStatusCode() == HttpStatus.OK
        result.getBody().contains(resultGame)

        where:
        dto                             | resultGame        | input
        new PlayerDTO("user", "game1")  | new Game("game1") | "user"
        new PlayerDTO("user2", "game1") | new Game("game1") | "user2"
        new PlayerDTO("user2", "game3") | new Game("game3") | "user2"
    }

    def "When loved with parameter is called should return most loved games"() {
        when:
        dtos.forEach({ dto -> playerController.add(dto) })
        def result = playerController.findTopLovedGames(top)
        then:
        result.getStatusCode() == HttpStatus.OK
        result.getBody().containsAll(resultLovedGames)

        where:
        dtos                                                                           | top | resultLovedGames
        Arrays.asList(new PlayerDTO("user", "game1"), new PlayerDTO("user2", "game1")) | 1   | Arrays.asList(new LovedGamesDTO("game1", 2))
        Arrays.asList(new PlayerDTO("user", "game1"), new PlayerDTO("user2", "game2")) | 2   | Arrays.asList(new LovedGamesDTO("game1", 1), new LovedGamesDTO("game2", 1))
        Arrays.asList(new PlayerDTO("user", "game1"), new PlayerDTO("user2", "game2")) | 1   | Arrays.asList(new LovedGamesDTO("game1", 1))

    }
}
