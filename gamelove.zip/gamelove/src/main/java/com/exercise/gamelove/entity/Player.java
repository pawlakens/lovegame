package com.exercise.gamelove.entity;

import lombok.*;
import lombok.experimental.FieldDefaults;

import javax.persistence.*;
import java.util.Set;

@Entity
@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@FieldDefaults(level = AccessLevel.PRIVATE)
public class Player {

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  Long id;

  @EqualsAndHashCode.Include String name;

  @ManyToMany
  @JoinTable(
      name = "games_like",
      joinColumns = @JoinColumn(name = "player_id"),
      inverseJoinColumns = @JoinColumn(name = "game_id"))
  Set<Game> games;

  public Player(String name) {
    this.name = name;
  }
}
