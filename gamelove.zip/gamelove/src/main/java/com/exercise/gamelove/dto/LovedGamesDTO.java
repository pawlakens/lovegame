package com.exercise.gamelove.dto;

import lombok.*;
import lombok.experimental.FieldDefaults;

@AllArgsConstructor
@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class LovedGamesDTO {

  @EqualsAndHashCode.Include String name;

  @EqualsAndHashCode.Include int loves;
}
