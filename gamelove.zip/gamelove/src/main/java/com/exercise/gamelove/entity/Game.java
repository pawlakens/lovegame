package com.exercise.gamelove.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import lombok.experimental.FieldDefaults;

import javax.persistence.*;
import java.util.Set;

@Entity
@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@FieldDefaults(level = AccessLevel.PRIVATE)
public class Game {

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  Long id;

  @EqualsAndHashCode.Include String name;

  @ManyToMany(mappedBy = "games")
  @JsonIgnore
  Set<Player> players;

  public Game(String name) {
    this.name = name;
  }
}
