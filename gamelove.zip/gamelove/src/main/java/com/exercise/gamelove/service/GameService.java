package com.exercise.gamelove.service;

import com.exercise.gamelove.dto.LovedGamesDTO;
import com.exercise.gamelove.entity.Game;
import com.exercise.gamelove.repository.GameRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class GameService {

  private final GameRepository gameRepository;
  private static final int FIRST_PAGE = 0;

  public Game save(Game game) {
    return gameRepository.save(game);
  }

  public Game findByName(String name) {
    return gameRepository.findByName(name);
  }

  public List<LovedGamesDTO> findTopLovedGames(int top) {
    return gameRepository.findTopLovedGames(PageRequest.of(FIRST_PAGE, top));
  }
}
