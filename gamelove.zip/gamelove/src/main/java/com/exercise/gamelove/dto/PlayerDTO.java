package com.exercise.gamelove.dto;

import lombok.*;
import lombok.experimental.FieldDefaults;

@AllArgsConstructor
@RequiredArgsConstructor
@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class PlayerDTO {

  @EqualsAndHashCode.Include String name;

  @EqualsAndHashCode.Include String game;
}
