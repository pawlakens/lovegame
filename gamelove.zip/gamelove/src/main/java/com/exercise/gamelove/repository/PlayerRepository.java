package com.exercise.gamelove.repository;

import com.exercise.gamelove.entity.Player;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlayerRepository extends JpaRepository<Player, Long> {
  Player findByName(String name);
}
