package com.exercise.gamelove.service;

import com.exercise.gamelove.entity.Player;
import com.exercise.gamelove.repository.PlayerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class PlayerService {

  private final PlayerRepository playerRepository;

  public Player findByName(String name) {
    return playerRepository.findByName(name);
  }

  public Player save(Player player) {
    return playerRepository.save(player);
  }
}
