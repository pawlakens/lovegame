package com.exercise.gamelove;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GameloveApplication {

  public static void main(String[] args) {
    SpringApplication.run(GameloveApplication.class, args);
  }
}
