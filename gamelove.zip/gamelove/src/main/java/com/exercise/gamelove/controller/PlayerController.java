package com.exercise.gamelove.controller;

import com.exercise.gamelove.dto.LovedGamesDTO;
import com.exercise.gamelove.dto.PlayerDTO;
import com.exercise.gamelove.entity.Game;
import com.exercise.gamelove.entity.Player;
import com.exercise.gamelove.service.GameService;
import com.exercise.gamelove.service.PlayerService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@RestController
@RequestMapping("/api/player")
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class PlayerController {

  final PlayerService playerService;
  final GameService gameService;

  @PostMapping("/add")
  public ResponseEntity<Player> add(@RequestBody PlayerDTO playerDTO) {

    Player player = getPlayer(playerDTO);
    Game game = getGame(playerDTO);

    player.getGames().add(game);
    playerService.save(player);

    return new ResponseEntity<>(player, HttpStatus.CREATED);
  }

  private Game getGame(PlayerDTO playerDTO) {
    Game game = gameService.findByName(playerDTO.getGame());

    if (game == null) {
      game = gameService.save(new Game(playerDTO.getGame()));
      game.setPlayers(new HashSet<>());
    }

    return game;
  }

  private Player getPlayer(PlayerDTO playerDTO) {
    Player player = playerService.findByName(playerDTO.getName());

    if (player == null) {
      player = playerService.save(new Player(playerDTO.getName()));
      player.setGames(new HashSet<>());
    }

    return player;
  }

  @PostMapping("/remove")
  public ResponseEntity<Player> remove(@RequestBody PlayerDTO playerDTO) {
    Player player = playerService.findByName(playerDTO.getName());
    Game game = gameService.findByName(playerDTO.getGame());
    if (player != null && game != null) {
      player.getGames().remove(game);
      playerService.save(player);

      return new ResponseEntity<>(player, HttpStatus.OK);
    } else {
      return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
  }

  @GetMapping("/findAllByPlayer/{name}")
  public ResponseEntity<Set<Game>> findAllByPlayer(@PathVariable String name) {
    Player player = playerService.findByName(name);

    if (player != null) {
      return new ResponseEntity<>(player.getGames(), HttpStatus.OK);
    }

    return new ResponseEntity<>(HttpStatus.NOT_FOUND);
  }

  @GetMapping("/loved/{top}")
  public ResponseEntity<List<LovedGamesDTO>> findTopLovedGames(@PathVariable Integer top) {
    List<LovedGamesDTO> lovedGames = gameService.findTopLovedGames(top);
    return new ResponseEntity<>(lovedGames, HttpStatus.OK);
  }
}
