package com.exercise.gamelove.repository;

import com.exercise.gamelove.dto.LovedGamesDTO;
import com.exercise.gamelove.entity.Game;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface GameRepository extends JpaRepository<Game, Long> {
  Game findByName(String name);

  @Query(
      "select new com.exercise.gamelove.dto.LovedGamesDTO(g.name, size(g.players)) from Game g order by size(g.players) desc")
  List<LovedGamesDTO> findTopLovedGames(Pageable paging);
}
