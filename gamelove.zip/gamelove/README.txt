GameLove:

API:

POST /api/player/add - adds new player or game
sample request:
{
"name": "sample"
"game": "sample"
}

POST /api/player/remove - unlove game
sample request:
{
"name": "sample"
"game": "sample"
}

GET /api/player/findAllByPlayer/sample - finds all player games

GET /api/player/loved/x - most loved games, x = top loved games (example 5)